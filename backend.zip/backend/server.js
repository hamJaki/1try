// server.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './db.js';
import chatRoutes from './routes/chatRoutes.js';
import authRoutes from './routes/authRoutes.js';
import { initializeVectorStore } from './vectorStore.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 5002;

app.use(cors());
app.use(express.json());

// Connect to MongoDB
connectDB();

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Root route to handle the base URL
app.get('/', (req, res) => {
    res.send('Welcome to the backend API!');
});

// Use routes
app.use('/api/chat', chatRoutes);
app.use('/api/auth', authRoutes);

const startServer = async () => {
    try {
        await initializeVectorStore();
        console.log('Vector store initialization complete');
    } catch (error) {
        console.error('Failed to initialize vector store:', error);
        process.exit(1); // Exit the process if vector store initialization fails
    }
};

startServer();

export default app;
