// PDFLoader.js
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { OpenAIEmbeddings } from "@langchain/openai";
import fs from "fs";
import dotenv from 'dotenv';

dotenv.config();

const VECTOR_STORE_PATH = "PDFDocument.json";
// const PDF_PATH = "./1.pdf"; // Replace with your PDF filename

async function loadVectorStore() {
    if (fs.existsSync(VECTOR_STORE_PATH)) {
        console.log("Loading existing vector store...");
        const rawData = fs.readFileSync(VECTOR_STORE_PATH, 'utf-8');
        const parsedData = JSON.parse(rawData);

        // Manually reconstruct the vector store
        const embeddings = new OpenAIEmbeddings();
        const vectorStore = new MemoryVectorStore(embeddings);
        vectorStore.memoryVectors = parsedData;
        return vectorStore;
    }

    console.log("Vector store not found.");
    // If the vector store does not exist and we do not want to recreate it, return or handle accordingly
    throw new Error("Vector store not found.");
}

// If you still need the loadPDF function, but not to load the PDF file:
// async function loadPDF() {
//     console.log("Function to load PDF not used.");
// }

export { loadVectorStore };
